""" Caching exceptions """


class KeyNotFoundException(KeyError):
    """ The given key could not be found in the cache """
