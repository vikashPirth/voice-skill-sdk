""" Caching functions to facilitate L1/L2 caching """

from .decorators import CallCache
